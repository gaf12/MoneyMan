import 'dart:io';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:new_money/bankDetails.dart';
import 'package:new_money/cardAddition.dart';
import 'package:new_money/signup.dart';

class SplashBank extends StatefulWidget {
  const SplashBank({super.key});

  @override
  State<SplashBank> createState() => _SplashBankState();
}

class _SplashBankState extends State<SplashBank> {
  @override
  void initState() {
    super.initState();
    _navigate();
  }
  _navigate() async {
    await Future.delayed(Duration(milliseconds: 1500), () {});
    Navigator.pushReplacement(context,
        MaterialPageRoute(builder: (context) => cards()));
  }
  Widget build(BuildContext context) {
    return Scaffold(

      body: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Image.asset('assets/banks.png'),
              SizedBox(height: 10,),
              Text("Fetching bank details"),
              SizedBox(height: 10,),
             if (Platform.isIOS)
                const CupertinoActivityIndicator(
                  radius: 15,
                )
              else
                CircularProgressIndicator(
                ),
            ],
            // minAxisAlignment:
          ),
       ),
    );
  }
}

