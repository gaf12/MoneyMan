import 'package:flutter/material.dart';
import 'package:flutter/material.dart';
import 'package:flutter/material.dart';
import 'package:new_money/signup.dart';
// import 'package:new_money/storage_helper.dart';
import 'login.dart'; // Correctly import the login.dart file
import 'dart:io';
// import 'package:path_provider/path_provider.dart';


class SignUp extends StatefulWidget {
  const SignUp({super.key});
  @override
  State<SignUp> createState() => _SignUpState();
}

Future<void> WriteTOfile(String firstName, String lastName, String email, String password) async {
  File file = File('/Users/azamb/Desktop/userInfo.txt');
  try {
    // Open the file in write mode (creates the file if it doesn't exist)
    IOSink sink = file.openWrite(mode: FileMode.write);
    // Create a formatted string with the data separated by spaces
    String data = '$firstName $lastName $email $password\n';
    // Write the formatted data to the file
    sink.write(data);
    // Close the file
    await sink.close();
    print('Data written to the file.');
  } catch (e) {
    print('Error writing to the file: $e');
  }
}




class _SignUpState extends State<SignUp> {
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>(); // Add GlobalKey for the form
  String email = '';
  String firstName = '';
  String passWord = '';
  String lastName = '';

  void _submitForm() {
    if (_formKey.currentState!.validate()) {
      print('firstname: $firstName\n');
      print('lastName: $lastName\n');
      print('email: $email\n');
      print('password: $passWord\n');
      WriteTOfile(firstName, lastName, email, passWord);
    }
    Navigator.pushNamed(context, '/Agree');


  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Sign Up'),
        centerTitle: true,
        backgroundColor: Colors.amberAccent,
      ),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Form(
            key: _formKey,
            child: Column(
              children: [
                const Row(
                  children: [
                    Text(
                      'Money Man',
                      style: TextStyle(
                        fontSize: 20,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 10,),
                const Row(
                  children: [
                    Text(
                      'Sign up for the best experience',
                      style: TextStyle(
                        fontSize: 15,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 30,),
                Row(
                  children: [
                    Expanded(
                      child: TextFormField(
                        validator: (value){
                          if (value == null || value.isEmpty) {
                            return 'This field is required';
                          }
                          firstName = value;
                          return null;
                        },
                        decoration: const InputDecoration(
                          labelText: 'First Name',
                        ),
                      ),
                    ),
                    const SizedBox(width: 20),
                    Expanded(
                      child: TextFormField(
                        validator: (value){
                          if (value == null || value.isEmpty) {
                            return 'This field is required';
                          }
                          lastName = value;
                          return null;
                        },
                        decoration: const InputDecoration(
                          labelText: 'Last Name',
                        ),
                      ),
                    ),
                  ],
                ),
                Column(
                  children: [
                    TextFormField(
                      validator: (value){
                        if (value == null || value.isEmpty) {
                          return 'This field is required';
                        }
                        if (!value.contains('@') || !value.contains('.')) {
                          return 'Invalid email address';
                        }
                        email = value;
                        return null;
                      },
                      decoration: const InputDecoration(
                        labelText: 'Email*',
                      ),
                    ),
                    const SizedBox(width: 20),
                    TextFormField(
                      validator: (value){
                        if (value == null || value.isEmpty) {
                          return 'This field is required';
                        }
                        passWord = value;
                        return null;
                      },
                      decoration: const InputDecoration(
                        labelText: 'Password*',
                      ),
                    ),
                    const SizedBox(height: 20),
                    TextFormField (
                      validator: (value){
                        if (value == null || value.isEmpty) {
                          return 'This field is required';
                        }
                        if (passWord != value){
                          return 'Password doesn\'t match';
                        }
                        return null;
                      },
                      decoration: const InputDecoration(
                        labelText: 'Confirm Password*',
                      ),
                    ),
                    const SizedBox(height: 30),
                    TextFormField(
                      validator: (value){
                        if (value == null || value.isEmpty) {
                          return 'This field is required';
                        }
                        return null;
                      },
                      decoration: const InputDecoration(
                        labelText: 'Select Country',
                      ),
                    ),
                    SizedBox(height: 40),
                    ElevatedButton(
                      onPressed: _submitForm,
                      child: const Text(
                        'Sign Up',
                      ),
                    )
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
      bottomNavigationBar: BottomAppBar(
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Text('Have an account already?'),
            const SizedBox(width: 130),
            TextButton(
              onPressed: () {
              },
              child: const Text('Sign In'),
            ),
          ],
        ),
      ),
    );
  }
}