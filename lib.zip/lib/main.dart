
import 'package:flutter/material.dart';
import 'package:new_money/agreePage.dart';
import 'package:new_money/bankDetails.dart';
import 'package:new_money/signup.dart';
import 'package:new_money/splash.dart';
import 'package:new_money/splashBank.dart';

import 'accountPage.dart';
import 'login.dart';

void main() => runApp(MaterialApp(
  initialRoute: '/',
  routes:{
    '/' : (context) => const MoneyMan(),
    '/signup': (context) =>const SignUp(),
    '/splashOne' : (context) => const Splash(),
    '/accountPage' : (context) => const accoutHolder(),
    '/Agree' : (context) => Agreements(),
    '/bank' : (context) => const BankInfo(),
    '/fetch' : (context) => const SplashBank(),
  } ,
));