
#CS 411 - Assignment 3 Starter Code
#Breadth First Search on 15 Puzzle
#Sarit Adhikari
#Spring 2024
#Abdul Gaffir Zambi

import random
import math
import time
import psutil
import os
from collections import deque
import sys
import queue
from collections import defaultdict

# This class defines the state of the problem in terms of board configuration
class Board:
    def __init__(self, tiles):
        # set tiles to the Board Tiles
        self.tiles = tiles
        pass


    # This function returns the resulting state from taking particular action from current state
    def execute_action(self, action):
        pass



# This class defines the node on the search tree, consisting of state, parent and previous action
class Node:
    def __init__(self, state, parent, action):
        self.state = state
        self.parent = parent
        self.action = action
        pass

    # Returns string representation of the state
    def __repr__(self):
        return str(self.state.tiles)

    # Comparing current node with other node. They are equal if states are equal
    def __eq__(self, other):
        return self.state.tiles == other.state.tiles

    def __hash__(self):
        return hash(tuple(self.state.tiles))



class Search:

    # This function returns the list of children obtained after simulating the actions on current node
    def get_children(self, parent_node):
        #children node
        children = []
        # getting the tiles of the parent node
        tiles = parent_node.state.tiles
        # getting the index of the empty tiles or '0'
        pos_empty = tiles.index('0')
        # 4 X 4 
        col = 4
        row = 4
        # getting the two indexs col and row of the empty tile '0'
        open_row, open_col = divmod(pos_empty, col)
        R = (0, 1)  # Direction tuples corrected
        L = (0, -1)
        D = (1, 0)
        U = (-1, 0)
        
                # ---------------------------------- MOVE LEFT --------------------------------------
                # ---------------------------------- MOVE LEFT --------------------------------------
        # Calculate the row and column position after moving left
        row_after_move, col_after = open_row + L[0], open_col + L[1]
        # Check if the new column position is within the board boundaries
        if 0 <= col_after < col:
            # Calculate the index of the moved tile in the new configuration
            index_moved = row_after_move * col + col_after
            # Create a copy of the current tiles configuration
            temp_tiles3 = tiles[:]
            # Swap the empty tile with the tile to the left
            temp_tiles3[pos_empty], temp_tiles3[index_moved] = temp_tiles3[index_moved], temp_tiles3[pos_empty]
            # Append the resulting node to the children list with the action 'L'
            children.append(Node(Board(temp_tiles3), parent_node, 'L'))
        else:
            # If the move is not possible, retain the current configuration
            temp_tiles3 = tiles[:]  # No action is taken, retain the current tiles configuration

        
          # ---------------------------------- MOVE RIGHT -------------------------------------
        # Calculate the row and column position after moving right
        row_after_move, col_after = open_row + R[0], open_col + R[1]
        # Check if the new column position is within the board boundaries
        if 0 <= col_after < col:
            # Calculate the index of the moved tile in the new configuration
            index_moved = row_after_move * col + col_after
            # Create a copy of the current tiles configuration
            temp_tiles4 = tiles[:]
            # Swap the empty tile with the tile to the right
            temp_tiles4[pos_empty], temp_tiles4[index_moved] = temp_tiles4[index_moved], temp_tiles4[pos_empty]
            # Append the resulting node to the children list with the action 'R'
            children.append(Node(Board(temp_tiles4), parent_node, 'R'))
        else:
            # If the move is not possible, retain the current configuration
            temp_tiles4 = tiles[:]  # No action is taken, retain the current tiles configuration

        
           # --------------------------------------- MOVE UP --------------------------------
        # Calculate the row and column position after moving up
        row_after_move, col_after = open_row + U[0], open_col + U[1]
        # Check if the new row position is within the board boundaries
        if 0 <= row_after_move < row:
            # Calculate the index of the moved tile in the new configuration
            index_moved = row_after_move * col + col_after
            # Create a copy of the current tiles configuration
            temp_tiles2 = tiles[:]
            # Swap the empty tile with the tile above it
            temp_tiles2[pos_empty], temp_tiles2[index_moved] = temp_tiles2[index_moved], temp_tiles2[pos_empty]
            # Append the resulting node to the children list with the action 'U'
            children.append(Node(Board(temp_tiles2), parent_node, 'U'))
        else:
            # If the move is not possible, retain the current configuration
            temp_tiles2 = tiles[:]  # No action is taken, retain the current tiles configuration
        # print("move up   ", temp_tiles)

        # ------------------------------ MOVE DOWN ------------------------------------
        # Calculate the row and column position after moving down
        row_after_move, col_after = open_row + D[0], open_col + D[1]
        # Check if the new row position is within the board boundaries
        if 0 <= row_after_move < row:
            # Calculate the index of the moved tile in the new configuration
            index_moved = row_after_move * col + col_after
            # Create a copy of the current tiles configuration
            temp_tiles = tiles[:]
            # Swap the empty tile with the tile below it
            temp_tiles[pos_empty], temp_tiles[index_moved] = temp_tiles[index_moved], temp_tiles[pos_empty]
            # Append the resulting node to the children list with the action 'D'
            children.append(Node(Board(temp_tiles), parent_node, 'D'))
        else:
            # If the move is not possible, retain the current configuration
            temp_tiles = tiles[:]  # No action is taken, retain the current tiles configuration
        # print("move down ", temp_tiles) 
        return children


    # This function backtracks from current node to reach initial configuration. The list of actions would constitute a solution path
    def find_path(self, node):
        path = []
        while node.parent is not None:
            path.insert(0,node.action)
            node = node.parent
        return path

    def reconstruct_path(self, camfrom, current):
        total_path = [current]  # Initialize total_path as a list
        while current in camfrom.keys():
            current = camfrom[current]
            total_path.insert(0, current)  # Use insert method to prepend current to total_path
        return total_path

    
    def h(self, start):
        goal = ['1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '11', '12', '13', '14', '15', '0']
        get2 = start.state.tiles
        follow = 0
        for i in range(len(goal)):
            if get2[i] != goal[i]:
                follow += 1           
        return follow

    
    #    print(get)
    def A_Star(self,start,goal,h):
        openSet = {start}
        camefrom = {}
        gScore = defaultdict(lambda: float('inf'))
        gScore[start] = 0
        fScore = defaultdict(lambda: float('inf'))
        fScore[start] = self.h(start)
        # print(gScore[start])
    
        while openSet: 
            lowest_node = None
            lowest_val = float('inf')  # Initialize with infinity to find the minimum
            for node2 in openSet:   
                val = fScore[node2] 
                if val < lowest_val:
                    lowest_val = val  # Update the lowest value
                    lowest_node = node2  # Update the lowest node           
            current = lowest_node
            if self.goal_test(current.state.tiles):
                return self.reconstruct_path(camefrom,current)
            openSet.remove(current)      
            for node in self.get_children(current):
                tentative_gScore = gScore[current] 
                if tentative_gScore < gScore[node]:
                    camefrom[node] = current
                    gScore[node] = tentative_gScore
                    fScore[node] = tentative_gScore + self.h(node) 
                if node not in openSet:
                    openSet.add(node)
                    
        return None
                    
        
    def goal_test(self, cur_tiles):
        return cur_tiles == ['1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '11', '12', '13', '14', '15', '0']
    
    
    # print("here")
    def solve(self, input):
        initial_list = input.split(" ")
        root = Node(Board(initial_list), None, None)
        cur_tiles = ['1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '11', '12', '13', '14', '15', '0']
    
        total = self.A_Star(root,cur_tiles,self.h(root))
        total2 = total[-1]
        val = self.find_path(total2)
        print(val)
        # start_time = time.time()  # Record the start time
        # result, nodes_expanded = self.iterative_deepening_search(root)  # Perform IDDFS search
        # end_time = time.time()  # Record the end time

        # if result:
        #     print("Moves: " + "" .join(self.find_path(result)))
        #     print("Number of Nodes expanded: " + str(nodes_expanded))
        #     print("Time Taken:", end_time - start_time, "seconds")
        #     max_memory = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss  # Max memory usage in kilobytes
        #     print("Max Memory (Bytes):", max_memory * 1024)  # Convert to bytes
        #     keep = self.find_path(result)
        #     val = ""
        #     for s in keep:
        #         val += s     
        #     return val
        # else:
        #     print("No solution found.")
        #     return ""
# Testing the algorithm locally
if __name__ == '__main__':
    agent = Search()
    input_str = "1 2 3 4 5 6 11 7 0 9 10 8 13 14 15 12"
    agent.solve(input_str)