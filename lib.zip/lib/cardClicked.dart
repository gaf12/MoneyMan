import 'package:flutter/cupertino.dart';

class setLimit extends StatefulWidget {
  const setLimit({super.key});

  @override
  State<setLimit> createState() => _setLimitState();
}

class _setLimitState extends State<setLimit> {
  @override
  Widget build(BuildContext context) {
    return const Placeholder();
  }
}
