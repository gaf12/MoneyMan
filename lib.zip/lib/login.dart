import 'package:flutter/material.dart';
import 'package:flutter/material.dart';
import 'package:new_money/signup.dart';
// import 'package:new_money/storage_helper.dart';
import 'login.dart'; // Correctly import the login.dart file
import 'dart:io';


class MoneyMan extends StatefulWidget {
  const MoneyMan({super.key});
  @override
  _MoneyManState createState() => _MoneyManState();
}


class Person {
  String email;
  String passWord2;
  Person(this.email, this.passWord2);
}

class _MoneyManState extends State<MoneyMan>{
  String emailOne = '';
  String passWord = '';
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>(); // Add GlobalKey for the form
  List<Person>client = [];


  Future<List<String>> readLinesFromFile(String filePath) async {
    List<String> lines = [];
    try {
      File file = File(filePath);
      if (await file.exists()) {
        Stream<List<int>> inputStream = file.openRead();
        List<int> buffer = [];
        await for (List<int> data in inputStream) {
          for (int byte in data) {
            if (byte == 10) {
              // 10 is the ASCII code for newline ('\n')
              String line = String.fromCharCodes(buffer);
              lines.add(line);
              buffer.clear();
            } else {
              buffer.add(byte);
            }
          }
        }
      }
    } catch (e) {
      print('Error reading from the file: $e');
    }
    print('lines: $lines');
    return lines;
  }


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('LogIn'),
        centerTitle: true,
        backgroundColor: Colors.greenAccent,
      ),
      body: Container(
        decoration: BoxDecoration(
          image: DecorationImage(
              image: AssetImage('assets/backCover.JPG')
          ),
        ),
        child: Center(
          child: Padding(
            padding: const EdgeInsets.all(16.0),
            child: Form( // Wrap the form with a Form widget
              key: _formKey, // Assign the GlobalKey to the Form
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  const Row(
                    children: [
                      Text(
                        'Money Man',
                        style: TextStyle(
                          fontSize: 28,
                        ),
                      ),
                    ],
                  ),
                  const Row(
                    children: [
                      Text(
                        "Welcome to new companionship..",
                      ),
                    ],
                  ),
                  const SizedBox(height: 30),
                  TextFormField(
                    validator: (value) {
                      emailOne = value!;
                      if (value == null || value.isEmpty) {
                        return 'This field is required';
                      }

                      return null;
                    },
                    decoration: const InputDecoration(
                      labelText: 'Email*',
                    ),
                  ),
                  const SizedBox(height: 20),
                  TextFormField(
                    validator: (value){
                      passWord = value!;
                      if (value == null || value.isEmpty) {
                        return 'This field is required';
                      }
                      if (value.length < 8){
                        return 'The password must be at least 8 characters long';
                      }
                      bool containsSymbol = false;
                      List<String> symbols = [
                        '!', '~', '@', '#', '%', '^', '&', '*', '?', '+', '/', '-', '_'
                      ];
                      for (int i = 0; i < value.length; i++) {
                        if (symbols.contains(value[i])) {
                          containsSymbol = true;
                          break;
                        }
                      }
                      if (!containsSymbol) {
                        return 'The input must contain at least one symbol';
                      }
                      return null;
                    },
                    decoration: const InputDecoration(
                      labelText: 'Password*',
                    ),
                    obscureText: true, // If it's a password field
                  ),
                  const SizedBox(height: 20),
                  Row(
                    children: [
                      ElevatedButton(
                        onPressed: () {
                          if (_formKey.currentState!.validate()) {
                            print('password: $passWord\n');
                            Navigator.pushNamed(context, '/splashOne');
                            readLinesFromFile('/Users/azamb/Desktop/userInfo.txt');
                          }
                        },
                        child: const Text('SIGN IN'), // Add button label
                      ),
                    ],
                  ),
                  const SizedBox(height: 20),
                  TextButton(
                    onPressed: () {
                      print('Forgot Password button pressed');
                    },
                    child: const Text(
                      'Forgot Password',
                      style: TextStyle(
                        decoration: TextDecoration.underline, // Add underline decoration
                      ),
                    ),
                  )
                ],
              ),
            ),
          ),
        ),
      ),
      bottomNavigationBar: BottomAppBar(
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Text('Don\'t have an account?'),
            const SizedBox(width: 130),
            TextButton(
              onPressed: () {
                showModalBottomSheet<void>(
                  context: context,
                  builder: (BuildContext context) {
                    return Container(
                      height: 200,
                      width: 500,
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.only(
                          topLeft: Radius.circular(20),
                          topRight: Radius.circular(20),
                        ),
                      ),
                      child: Column(
                        children: [
                          SizedBox(height: 20),
                          Text(
                            'Sign Up Options',
                            style: TextStyle(
                              fontSize: 20,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          SizedBox(height: 20),
                          TextButton.icon(
                            onPressed: () {
                              Navigator.pushNamed(context,'/signup');
                            },
                            icon: Icon(Icons.person), // Icon
                            label: Text(
                              'Personal', // Text label
                              style: TextStyle(
                                fontSize: 18,
                              ),
                            ),
                          ),
                        ],
                      ),
                    );
                  },
                );
              },
              child: Text('Sign Up'),
            ),
          ],
        ),
      ),
    );
  }
}

