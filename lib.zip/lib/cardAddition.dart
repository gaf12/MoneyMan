import 'package:flutter/material.dart';

class cards extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Bank Details"),
        centerTitle: true,
        backgroundColor: Colors.blue,
      ),
      body: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Text(
              "Your Account Ending in: XXXX",
              style: TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.bold,
              ),
            ),
            SizedBox(height: 20),
            Text(
              "Has a Balance of: \$20",
              style: TextStyle(
                fontSize: 20,
              ),
            ),
            SizedBox(height: 10),
            Text(
              "Card/Cards linked to the account:",
              style: TextStyle(
                fontSize: 18,
              ),
            ),
            SizedBox(height: 20),
            Expanded(
              child: ListView.builder(
                itemCount: 3, // Adjust the count as per your data
                itemBuilder: (context, index) {
                  // Placeholder for card info
                  return Card(
                    elevation: 2,
                    margin: EdgeInsets.symmetric(vertical: 8),
                    child: ListTile(
                      leading: Icon(Icons.credit_card),
                      title: Text("Card ${index + 1}"),
                      subtitle: Text("Card Info Placeholder"),
                      trailing: Icon(Icons.arrow_forward),
                      onTap: () {

                      },
                    ),
                  );
                },
              ),
            ),
            // SizedBox(height: 10),
            Text(" Click on any card to set limit on card"),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: () {
                // Handle add new card button press
              },
              child: Text("Add New Card"),
            ),
          ],
        ),
      ),
    );
  }
}